<?php
class User_model extends CI_model{
 
    public function register_user($user)
    {
        $this->db->insert('user', $user);
    }
 
    public function login_user($user_email,$user_password)
    {
        $this->db->where('user_email',$user_email);
        $this->db->where('user_password',$user_password);
        $this->db->select('*');
        $this->db->from('user');
        if($query = $this->db->get())
        {
            return $query->result_array();
        }else{
            return NULL;
        }
    }

    public function email_check($email)
    {
        $this->db->where('user_email',$email);
        $query = $this->db->get('user');
        if($query->num_rows()>0)
        {
            return false;
        }else{
            return NULL;
        }
    }

    public function fetch_user_hobbies()
    {
        $this->db->select('*');
        $this->db->join('user AS US','US.user_id = UHD.user_id_fk', 'INNER');
        if($_SESSION['user_role'] != "Admin")
        {
            $this->db->where('UHD.user_id_fk', $_SESSION['user_id']);
        }
        $query = $this->db->get('user_hobbies_data AS UHD');
        if ($query -> num_rows() > 0) 
        {
            return $query->result_array();
        }else{
            return NULL;
        }
    }

    public function insert_data($data)
    {
        $data = array(
                    'user_id_fk' => $data['user_id'],
                    'user_hobbies' => $data['user_hobbies'],
                    'user_other_hobby' => $data['user_sub_hobbies']
                    );
        $this -> db -> insert('user_hobbies_data', $data);

        if ($this -> db -> affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }

    public function fetch_hobbies_name($data)
    {
        $this->db->where('user_hobbies',$data['hobbies']);
        $query = $this -> db -> get('user_hobbies_data');
        if ($query -> num_rows() > 0)
        {
            return $query->result();
        }
        else
        {
            return NULL;
        }
    }

    public function update_hobbies_data($hobbies_id,$edit_hobbies,$edit_subhobbies)
    {
        $data = array(
                      'user_hobbies'   => $edit_hobbies,
                      'user_other_hobby' => $edit_subhobbies
                    );  
        $this->db->where('hobb_id', $hobbies_id);
        $query = $this->db->update('user_hobbies_data', $data);
        if ($query) 
        {
            return TRUE;
        } else {
            return FALSE;
        }   
    }

    public function delete_hobbies($hobbies_id)
    {
        $this -> db -> where('hobb_id', $hobbies_id);
        $this -> db -> delete('user_hobbies_data');

        if ($this -> db -> affected_rows() > 0) {
            return true;
        } else {
            return false;
        }
    }
}
?>