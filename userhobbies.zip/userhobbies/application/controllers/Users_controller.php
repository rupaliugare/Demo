<?php

class Users_controller extends CI_Controller {

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
        $this->load->model('user_model');
        $this->load->library('session');
    }

    public function index()
    {
        $data['page_title'] = "Login Registration";
        $this->session->set_flashdata('error_msg', '');
        $this->session->set_flashdata('success_msg', '');
        $data['main_content'] = array('user_login/register');
        $this -> load -> view('bootstrap_templates/main_template', $data);
    }

    public function register_user()
    {
        $user = array(
            'user_name'=>$this->input->post('user_name'),
            'user_email'=>$this->input->post('user_email'),
            'user_password'=>md5($this->input->post('user_password')),
            'user_age'=>$this->input->post('user_age'),
            'user_mobile'=>$this->input->post('user_mobile')
        );
        $email_check = $this->user_model->email_check($user['user_email']);
        if($email_check != NULL)
        {
            $this->user_model->register_user($user);
            $this->session->set_flashdata('success_msg', 'Registered successfully.Now login to your account.');
            redirect('login/login_view');
        }else{
            $this->session->set_flashdata('error_msg', 'Error occured,Try again.');
            redirect('login/login_view');
        }
    }

    public function login_view()
    {
        $data['page_title'] = "Login to Your Account";
        $data['main_content'] = array('user_login/login');
        $this -> load -> view('bootstrap_templates/main_template', $data);
    }

    public function login_user()
    { 
        $user_email= $this->input->post('user_email');
        $user_password = md5($this->input->post('user_password'));
        $data['users']=$this->user_model->login_user($user_email,$user_password);
        if($data['users'] != NULL)
        {
            $this->session->set_userdata('user_id',$data['users'][0]['user_id']);
            $this->session->set_userdata('user_email',$data['users'][0]['user_email']);
            $this->session->set_userdata('user_name',$data['users'][0]['user_name']);
            $this->session->set_userdata('user_age',$data['users'][0]['user_age']);
            $this->session->set_userdata('user_mobile',$data['users'][0]['user_mobile']);
            if($user_email == 'admin@gmail.com')
            {
                $this->session->set_userdata('user_role','Admin');
            }else{
                $this->session->set_userdata('user_role','User');
            }
            redirect('login/user_profile');
        }else{
            $this->session->set_flashdata('error_msg', 'Password or Email is incorrect');
            $data['main_content'] = array('user_login/login');
            $this -> load -> view('bootstrap_templates/main_template', $data);
        } 
    }

    public function user_logout()
    {
        $this->session->sess_destroy();
        redirect('login/login_view', 'refresh');
    }

    public function user_profile()
    {
        $user_fetch_hobbies = $this -> user_model -> fetch_user_hobbies();
        if($user_fetch_hobbies != NULL)
        {
            $data['user_hobbies'] = $user_fetch_hobbies; 
        }else{
            $data['user_hobbies'] = NULL; 
        }

        $data['main_content'] = array('user_login/user_profile');
        $this -> load -> view('bootstrap_templates/main_template', $data);
    }

    public function add_hobbies()
    {
        $data['user_hobbies']= $this->input->post('user_hobbies');
        $data['user_sub_hobbies'] = $this->input->post('user_sub_hobbies');
        $data['user_id']=$_SESSION['user_id'];
        $result = $this -> user_model -> insert_data($data);
        if ($result == true) 
        {
            echo "1";return;
        } else 
        {
            echo "Could not insert.";
            redirect('login/user_profile');
        }
    }

    public function ajax_check_name()
    {
        $data['hobbies'] =  $this->input->post('hobbies');
        $return_name_data= $this-> user_model -> fetch_hobbies_name($data);
        if($return_name_data != NULL)
        {
            echo "1";return;
        }
    }

    public function ajax_update_hobbies()
    {
        $hobbies_id        = $this->input->post('hobbies_id');
        $edit_hobbies  = $this->input->post('edit_hobbies');
        $edit_subhobbies  = $this->input->post('edit_subhobbies');

        echo $data['ret_hobbies_update'] = $this -> user_model -> update_hobbies_data($hobbies_id,$edit_hobbies,$edit_subhobbies);return;   
    }

    public function ajax_delete_hobbies()
    {
        $hobbies_id        = $this->input->post('hobbies_id');
        echo $data['ret_hobbies_delete'] = $this -> user_model ->delete_hobbies($hobbies_id);return;   
    }
}
?>