<!DOCTYPE html>
<!-- Main Header Start -->
	<html lang="en">
	  <head>
	    <base href="<?php echo base_url() ?>" target="_self">
	    <meta charset="utf-8" /> <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0"/>
	    <meta name="viewport" content="width=device-width, initial-scale=1.0, minimum-scale=1.0"/>
	    <title>User Details</title>
<!-- Main Header End -->