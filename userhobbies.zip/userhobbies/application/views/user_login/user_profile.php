<style type="text/css">
  .table_blue_color th
    {
        color: #fff;
        background-color: #428bca;
        border-color: #357ebd;
        font-weight: 400;
        text-align: center;
    }
</style>
<script type="text/javascript">
    function add_hobbies() 
    {
    	var user_hobbies = $("#user_hobbies").val();
		var user_sub_hobbies = $("#user_sub_hobbies").val();
        if($('#user_hobbies').val() == '' || $('#user_hobbies').val() == null)
        {
        	alert("Please enter Hobby");
        	$('#user_hobbies').focus();
        	return;
        }
        if($('#user_sub_hobbies').val() == '' || $('#user_sub_hobbies').val() == null)
        {
        	alert("Please enter Sub Hobby");
        	$('#user_sub_hobbies').focus();
        	return;
        }
		var controller = 'login';
        var base_url = '<?php echo site_url(); ?>'; 
        var url = base_url + '/' + controller + '/' + 'add_hobbies' ;
        $.ajax
        ({
            'url' :  url,
            'type' : 'POST', 
            'data' : {'user_hobbies':user_hobbies,'user_sub_hobbies':user_sub_hobbies},
            'success' : function(html_data)
            {   
                if(html_data)
                {
                	if (confirm("Are you sure do you want to Add ?")) 
                	{
				       alert('Hobby Added successfully!');
                    	location.reload();
                	}
                }else{
                	alert('Something went wrong. Please try again!');
				    return false;
                }
            }
        });
    }

    function check_name(key)
    {
        var hobbies    = $(key).val().trim();
        var controller = 'login';
        var base_url   = '<?php echo site_url(); ?>'; 
        var url        = base_url + '/' + controller + '/' + 'ajax_check_name' ;
        $.ajax
        ({
            'url' :  url,
            'type' : 'POST', //the way you want to send data to your URL
            'data' : {'hobbies' : hobbies},
            'success' : function(data)
            {
                if(data == '1')
                {
                    alert("This Hobby Name is already exists.");
                    $(key).val('');
                    return false;
                }else 
                {
                    $(key).val(hobbies);
                }           
            }
        });
    }

    function edit_hobbies(edit,hobbies_id)
    {
        var edit_id = $(edit).attr("id");
        var class_name = $(edit).attr('class');

        if (class_name.indexOf("edit-item") != -1)
        {
            $("#"+edit_id).attr('class', 'icon-effect fa fa-save save-item');
            var hobbies = $("#hobbies"+hobbies_id).html().trim();
            var sub_hobbies = $("#sub_hobbies"+hobbies_id).html().trim();
            var input_hobbies = $("<input>", {value:hobbies, type:"text", id:"input_hobbies"+hobbies_id,name:"input_hobbies"+hobbies_id});
            var input_subhobbies = $("<input>", {value:sub_hobbies, type:"text", id:"input_subhobbies"+hobbies_id,name:"input_subhobbies"+hobbies_id});
            $("#hobbies"+hobbies_id).replaceWith(input_hobbies);
            $("#sub_hobbies"+hobbies_id).replaceWith(input_subhobbies);
        }
        else
        {
            $("#"+edit_id).attr('class', 'fa fa-edit edit-item');
            var edit_hobbies = $("#input_hobbies"+hobbies_id).val().trim();
            var edit_subhobbies  = $("#input_subhobbies"+hobbies_id).val().trim();

            if(edit_hobbies == '' || edit_hobbies == null)
	        {
	        	alert("Please enter Hobby");
	        	$("#input_hobbies"+hobbies_id).focus();
	        	return;
	        }
	        if(edit_subhobbies == '' || edit_subhobbies == null)
	        {
	        	alert("Please enter Sub Hobby");
	        	$("#input_subhobbies"+hobbies_id).focus();
	        	return;
	        }
            var span_hobbies = $("<span>", { text: edit_hobbies,id:"hobbies"+hobbies_id,name:"hobbies"+hobbies_id});
            var span_subhobbies= $("<span>", { text: edit_subhobbies,id:"sub_hobbies"+hobbies_id,name:"sub_hobbies"+hobbies_id});
           
            $("#input_hobbies"+hobbies_id).replaceWith(span_hobbies);
            $("#input_subhobbies"+hobbies_id).replaceWith(span_subhobbies);

            var controller = 'login';
            var base_url = '<?php echo site_url(); ?>'; 
            var url = base_url + '/' + controller + '/' + 'ajax_update_hobbies' ;
            $.ajax
            ({
                'url' :  url,
                'type' : 'POST',
                'data' : {'hobbies_id' : hobbies_id,'edit_hobbies':edit_hobbies, 'edit_subhobbies' : edit_subhobbies},
                'success' : function(data)
                {     
                    if(data){
                    	alert("Hobby Updated successfully!");
                    	location.reload();
	                }else{
	                    alert("Something wants wrong!");
	                    return;
                	}
                }
            });     
        }
    }

    function delete_hobbies(hobbies_id) 
    {
        var base_url = '<?php echo site_url(); ?>'; 
        var url = base_url + '/' + 'login' + '/' + 'ajax_delete_hobbies';
        $.ajax
        ({
            'url' :  url,
            'type' : 'POST',
            'data' : {
                'hobbies_id' : hobbies_id
            },
            'async' :false,
            success : function(data)
            {   
                if(data){
                    alert("Hobby deleted successfully!");
                    location.reload();
                }else{
                    alert("Something wants wrong!");
                    return;
                }
            }
        });
    }
</script>
<ul class="sky-mega-menu sky-mega-menu-response-to-icons">
	<!-- Right Section Start -->
	<div style="float: right;">
		<li>&nbsp;</li>
		<li>
			<li aria-haspopup="true">
				<a href = "http://localhost/userhobbies/indexCI.php//login/user_logout">
					<i class="fa fa-sign-out"></i><?php echo $_SESSION['user_name'];?>
				</a>
			</li>
		</li>
	</div>
</ul>			
<div class="container-fluid" >
    <span style="float: left;color:black;"><h4><b><i></i><?php echo "User Hobbies"; ?></b></h4></span>
    <span style="float: right;color:black;"><h4><b><i class="fa fa-calendar"></i> <?php echo date("d M Y"); ?></b></h4></span>
    <br>
    <br>
    <br>
    <?php
    $display = 'display:none';
    $ret_display = '';
	if ($_SESSION['user_role'] != "Admin") 
	{
		$display = '';
    	$ret_display = 'display:none';
	}
	?>   
	<center>
		<a class="modalbox btn btn-primary"  style="margin-bottom:1%;margin-top:1%;<?php echo $display;?>" href="#ex1" id="add_button" data-target="#ex1" data-toggle="modal">Add</a>
	</center>	
	<?php if ($user_hobbies != NULL) {?>
    <div class="table-responsive">
		<table class="table table-bordered table-striped table-condensed table_blue_color" id="student_rapid_list">
            <thead>
                <tr>
                    <th class="text-center">Sr No</th>
					<th class="text-center" style="<?php echo $ret_display;?>">User Name</th>
					<th class="text-center">User Hobby</th>
					<th class="text-center">User Sub Hobby</th>
					<th class="text-center" style="<?php echo $display;?>">Action</th>
				</tr>
            </thead>
            <tbody>
                <?php
                   foreach ($user_hobbies as $key => $user_data)
                   {
                    ?>
                    <tr>
                        <td>
                            <input type="hidden" value="<?php echo $key++; ?>">
                            <?php echo $key; ?>
                        </td>
                        <td id="user_name<?php echo $key; ?>" style="<?php echo $ret_display;?>"><?php echo $user_data['user_name']; ?></td>
                        <td>
                        	<span id="hobbies<?php echo $user_data['hobb_id'];?>" name="hobbies<?php echo $user_data['hobb_id'];?>"><?php echo $user_data['user_hobbies'];?>
                        	</span>
                        </td>
                        <td>
                        	<span id="sub_hobbies<?php echo $user_data['hobb_id'];?>" name="sub_hobbies<?php echo $user_data['hobb_id'];?>"><?php echo $user_data['user_other_hobby'];?>
                        	</span>
                        </td>		
                        <td style="<?php echo $display;?>">
	                        <i class='fa fa-pencil-square-o icon-effect edit-item' title='Edit' id="hobbies_edit<?php echo $user_data['hobb_id'];?>" style="text-align:center; font-size:20px;" onclick="edit_hobbies(this,'<?php echo $user_data['hobb_id'];?>');"></i>
	                        <i class="fa fa-trash-o icon-effect" id="manual_delete" onclick="delete_hobbies('<?php echo $user_data['hobb_id'];?>')" style="text-align:center; font-size:20px;"></i>
	                    </td>
                    </tr>
                    <?php
                   }?>
            </tbody>
        </table>
    </div>
    <?php }?>
    <div class="modal fade" id="ex1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog" style="padding-top: 10%;">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title"><b>Enter User Hobbies</b></h4>
            </div>
            <div class="modal-body">
                <div class="row text-center">
                    <div class="col-md-2 text-left">
                        <label>Hobby :</label>
                    </div>
                    <div class="col-md-4">
                        <input class="form-control" placeholder="Please enter hobbies" name="user_hobbies" id="user_hobbies" type="text" onchange="check_name(this);" required>
                    </div>
                    <div class="col-md-2 text-left">
                        <label>Sub Hobby :</label>
                    </div>
                    <div class="col-md-4">
                        <input class="form-control" placeholder="Enter comma separated sub hobbies" name="user_sub_hobbies" id="user_sub_hobbies" type="text" required>
                    </div>
                </div>
                <br>
                <div class="row text-center">
                    <button class="btn btn-primary" id="class_changes_add"  type="button" onClick="add_hobbies();" data-dismiss="modal">Add</button>
                </div>
            </div>        
        </div>
    </div>
</div>